plugins {
    alias(libs.plugins.android.application)
}

android {
    buildFeatures { buildConfig = true }
    namespace = "com.escola.cantina"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.escola.cantina"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        val dbHost = providers.gradleProperty("CANTINA_DB_HOST").orElse("10.0.2.2").get()
        val dbPort = providers.gradleProperty("CANTINA_DB_PORT").orElse("3306").get()
        val dbName = providers.gradleProperty("CANTINA_DB_NAME").orElse("cantina_escolar_vanders").get()
        val dbUser = providers.gradleProperty("CANTINA_DB_USER").orElse("root").get()
        val dbPasswordLower = providers.gradleProperty("cantina_bd_password").orNull.orEmpty()
        val dbPasswordUpper = providers.gradleProperty("CANTINA_DB_PASSWORD").orNull.orEmpty()
        val dbPassword = dbPasswordLower.ifBlank { dbPasswordUpper }
        buildConfigField("String", "DB_HOST", "\"$dbHost\"")
        buildConfigField("String", "DB_PORT", "\"$dbPort\"")
        buildConfigField("String", "DB_NAME", "\"$dbName\"")
        buildConfigField("String", "DB_USER", "\"$dbUser\"")
        buildConfigField("String", "DB_PASSWORD", "\"$dbPassword\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {

    // MySQL Connector Java
    implementation("com.mysql:mysql-connector-j:8.4.0")
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}




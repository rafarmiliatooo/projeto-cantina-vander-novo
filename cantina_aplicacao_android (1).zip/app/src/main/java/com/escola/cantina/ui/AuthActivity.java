package com.escola.cantina.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.escola.cantina.BuildConfig;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class AuthActivity extends AppCompatActivity {
    private EditText cpf;
    private EditText senha;
    private EditText nome;
    private EditText turma;
    private Spinner perfil;
    private LinearLayout cadastro;
    private Button botaoAcao;
    private boolean novo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        montarTela();
    }

    private void montarTela() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout conteudo = new LinearLayout(this);
        conteudo.setOrientation(LinearLayout.VERTICAL);
        conteudo.setPadding(30, 40, 30, 30);
        scroll.addView(conteudo);

        TextView titulo = new TextView(this);
        titulo.setText("Cantina escolar");
        titulo.setTextSize(26);
        conteudo.addView(titulo);

        cpf = campo(conteudo, "CPF (11 números)", InputType.TYPE_CLASS_NUMBER);
        senha = campo(conteudo, "Senha",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        cadastro = new LinearLayout(this);
        cadastro.setOrientation(LinearLayout.VERTICAL);
        conteudo.addView(cadastro);

        nome = campo(cadastro, "Nome completo", InputType.TYPE_CLASS_TEXT);

        perfil = new Spinner(this);
        perfil.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Responsável", "Aluno", "Funcionário"}));
        cadastro.addView(perfil);

        turma = campo(cadastro, "Turma do aluno", InputType.TYPE_CLASS_TEXT);
        perfil.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                turma.setVisibility(View.GONE);
            }

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                turma.setVisibility(position == 1 ? View.VISIBLE : View.GONE);
            }
        });

        botaoAcao = new Button(this);
        botaoAcao.setText("Entrar");
        conteudo.addView(botaoAcao);

        Button alternarModo = new Button(this);
        alternarModo.setText("Criar conta");
        conteudo.addView(alternarModo);

        cadastro.setVisibility(View.GONE);
        botaoAcao.setOnClickListener(view -> autenticar());
        alternarModo.setOnClickListener(view -> {
            novo = !novo;
            cadastro.setVisibility(novo ? View.VISIBLE : View.GONE);
            botaoAcao.setText(novo ? "Cadastrar" : "Entrar");
            alternarModo.setText(novo ? "Voltar ao login" : "Criar conta");
        });

        setContentView(scroll);
    }

    private EditText campo(LinearLayout pai, String dica, int tipo) {
        EditText campo = new EditText(this);
        campo.setHint(dica);
        campo.setInputType(tipo);
        pai.addView(campo);
        return campo;
    }

    private Connection abrirConexao() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://" + BuildConfig.DB_HOST + ":" + BuildConfig.DB_PORT + "/"
                + BuildConfig.DB_NAME
                + "?useSSL=false&allowPublicKeyRetrieval=true&connectTimeout=8000&socketTimeout=8000";
        return DriverManager.getConnection(url, BuildConfig.DB_USER, BuildConfig.DB_PASSWORD);
    }

    private String hashSenha(String valor) throws Exception {
        byte[] bytes = MessageDigest.getInstance("SHA-256")
                .digest(valor.getBytes(StandardCharsets.UTF_8));
        StringBuilder hash = new StringBuilder();
        for (byte b : bytes) {
            hash.append(String.format("%02x", b));
        }
        return hash.toString();
    }

    private void autenticar() {
        String cpfDigitado = cpf.getText().toString().replaceAll("\\D", "");
        String senhaDigitada = senha.getText().toString();
        String nomeDigitado = nome.getText().toString().trim();
        String turmaDigitada = turma.getText().toString().trim();
        int perfilSelecionado = perfil.getSelectedItemPosition();
        int perfilCadastro = perfilSelecionado == 0 ? 3 : (perfilSelecionado == 1 ? 2 : 1);
        boolean criandoConta = novo;

        if (cpfDigitado.length() != 11 || senhaDigitada.length() < 6) {
            mostrarMensagem("Informe um CPF com 11 números e senha com pelo menos 6 caracteres.");
            return;
        }
        if (criandoConta && (nomeDigitado.isEmpty() || (perfilCadastro == 2 && turmaDigitada.isEmpty()))) {
            mostrarMensagem("Preencha o nome e, para aluno, informe também a turma.");
            return;
        }

        botaoAcao.setEnabled(false);
        new Thread(() -> {
            int statusPerfil = perfilCadastro;
            try (Connection conexao = abrirConexao()) {
                int idUsuario;
                String nomeUsuario;
                if (criandoConta) {
                    String sql = "INSERT INTO usuarios (nome, cpf, senha, status_perfil, turma) "
                            + "VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement comando = conexao.prepareStatement(
                            sql, Statement.RETURN_GENERATED_KEYS)) {
                        comando.setString(1, nomeDigitado);
                        comando.setString(2, cpfDigitado);
                        comando.setString(3, hashSenha(senhaDigitada));
                        comando.setInt(4, statusPerfil);
                        if (statusPerfil == 2) {
                            comando.setString(5, turmaDigitada);
                        } else {
                            comando.setNull(5, Types.VARCHAR);
                        }
                        comando.executeUpdate();
                        try (ResultSet chaves = comando.getGeneratedKeys()) {
                            if (!chaves.next()) {
                                throw new SQLException("O MySQL não retornou o ID do usuário cadastrado.");
                            }
                            idUsuario = chaves.getInt(1);
                        }
                    }
                    nomeUsuario = nomeDigitado;
                } else {
                    String sql = "SELECT id, nome, senha, status_perfil FROM usuarios WHERE cpf = ?";
                    try (PreparedStatement comando = conexao.prepareStatement(sql)) {
                        comando.setString(1, cpfDigitado);
                        try (ResultSet resultado = comando.executeQuery()) {
                            if (!resultado.next()) {
                                throw new IllegalArgumentException("CPF ou senha inválidos.");
                            }
                            String senhaSalva = resultado.getString("senha");
                            if (!senhaSalva.equals(senhaDigitada)
                                    && !senhaSalva.equals(hashSenha(senhaDigitada))) {
                                throw new IllegalArgumentException("CPF ou senha inválidos.");
                            }
                            idUsuario = resultado.getInt("id");
                            nomeUsuario = resultado.getString("nome");
                            statusPerfil = resultado.getInt("status_perfil");
                        }
                    }
                }

                int idFinal = idUsuario;
                int perfilFinal = statusPerfil;
                String nomeFinal = nomeUsuario;
                runOnUiThread(() -> abrirTelaPerfil(idFinal, perfilFinal, nomeFinal));
            } catch (Exception erro) {
                String mensagem = mensagemDeErro(erro);
                runOnUiThread(() -> {
                    botaoAcao.setEnabled(true);
                    mostrarMensagem(mensagem);
                });
            }
        }).start();
    }

    private String mensagemDeErro(Exception erro) {
        if (erro instanceof IllegalArgumentException || erro instanceof IllegalStateException) {
            return erro.getMessage();
        }
        if (erro instanceof ClassNotFoundException) {
            return "Driver JDBC do MySQL não encontrado. Sincronize o projeto Gradle.";
        }
        if (erro instanceof SQLException) {
            SQLException sql = (SQLException) erro;
            switch (sql.getErrorCode()) {
                case 1045:
                    return "MySQL recusou o usuário ou a senha. Confira CANTINA_DB_USER e CANTINA_DB_PASSWORD.";
                case 1049:
                    return "O banco informado não existe. Confira CANTINA_DB_NAME e execute o SQL de criação.";
                case 1062:
                    return "Este CPF já está cadastrado.";
                case 1146:
                    return "A tabela usuarios não existe. Execute o script banco_cantina_corrigido.sql.";
                default:
                    if (sql.getSQLState() != null && sql.getSQLState().startsWith("08")) {
                        return "Não foi possível alcançar o MySQL em " + BuildConfig.DB_HOST + ":"
                                + BuildConfig.DB_PORT + ". Inicie o MySQL e confira o host/porta.";
                    }
                    return "Erro MySQL " + sql.getErrorCode() + ": " + sql.getMessage();
            }
        }
        return erro.getMessage() == null ? "Falha inesperada ao acessar o banco." : erro.getMessage();
    }

    private void abrirTelaPerfil(int id, int statusPerfil, String nomeUsuario) {
        Intent intent;
        if (statusPerfil == 3) {
            intent = new Intent(this, FamilyHomeActivity.class);
            intent.putExtra("EXTRA_ID_RESPONSAVEL", id);
        } else if (statusPerfil == 2) {
            intent = new Intent(this, StudentActivity.class);
            intent.putExtra("USER_ID", id);
        } else {
            intent = new Intent(this, com.example.cantinavander.MainActivity.class);
            intent.putExtra("USER_ID", id);
            intent.putExtra("ROLE", statusPerfil);
            intent.putExtra("USER_NAME", nomeUsuario);
        }
        startActivity(intent);
        finish();
    }

    private void mostrarMensagem(String mensagem) {
        Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();
    }
}







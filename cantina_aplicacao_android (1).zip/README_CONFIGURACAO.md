# Cantina Escolar — configuração

## Banco

1. Execute `banco_cantina_corrigido.sql` no MySQL. O arquivo original apagava todas as tabelas ao final; a cópia de entrega remove esses `DROP TABLE`.
2. Configure as propriedades Gradle antes de sincronizar o projeto. No arquivo `gradle.properties` do projeto (ou em `%USERPROFILE%\.gradle\gradle.properties`), informe:

```properties
CANTINA_DB_HOST=192.168.20.5
CANTINA_DB_PORT=3306
CANTINA_DB_NAME=cantina_escolar_vanders
CANTINA_DB_USER=root
cantina_bd_password=SUA_SENHA_REAL
```

Troque `SUA_SENHA_REAL` pela senha usada no seu MySQL. O Gradle também aceita `CANTINA_DB_PASSWORD` como nome alternativo. Não deixe a linha vazia. `10.0.2.2` funciona no emulador Android para acessar o PC; em aparelho físico, use o IP LAN do computador. MySQL deve aceitar conexões nessa interface e a porta 3306 deve estar acessível.

## Funcionalidades alteradas

- Login por CPF e senha; cadastro de responsável, aluno (com turma) e funcionário.
- Novas senhas são gravadas com SHA-256; login mantém compatibilidade com senhas antigas em texto simples.
- Cadastro e edição de produto com categoria e disponibilidade em `produtos`.
- Cardápio do aluno, carrinho e pedido antecipado gravados em `pedidos` e `itens_pedido`, com código de retirada, intervalo, alergia e validação de saldo/limites.
- Sessão do responsável usa o ID autenticado em vez de assumir usuário `1`.

## Executar

Abra a pasta `cantina_aplicacao` no Android Studio, configure o Android SDK no `local.properties` (o Android Studio normalmente faz isso) e sincronize Gradle. A compilação `:app:assembleDebug` foi concluída com sucesso. O APK foi gerado em `app/build/outputs/apk/debug/app-debug.apk`. O cadastro ainda exige que o MySQL esteja ativo e que as propriedades reais de conexão estejam configuradas.

> Para produção, não conecte um app distribuído diretamente ao MySQL nem embuta credenciais no APK. Use uma API autenticada entre o app e o banco.


## Diagnóstico de conexão

A tela agora diferencia senha/configuração vazia, usuário/senha recusados, banco/tabela inexistentes e indisponibilidade do host. Para o emulador, 10.0.2.2 aponta para o computador host; o serviço MySQL precisa estar escutando em TCP na porta configurada e o usuário MySQL precisa aceitar a conexão. Neste ambiente não foi encontrado servidor respondendo em 127.0.0.1:3306. O usuário recebeu apenas sua_senha_aqui, que é um marcador, não uma senha real.





